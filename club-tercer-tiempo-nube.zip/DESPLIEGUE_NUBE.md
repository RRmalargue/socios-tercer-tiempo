# Guía de Despliegue en la Nube - Club Tercer Tiempo

Esta guía explica paso a paso cómo subir y mantener el sistema del **Club Social y Deportivo Tercer Tiempo** en internet para que tu amigo, la comisión directiva y los socios puedan acceder desde cualquier celular o computadora con conexión a internet.

---

## 🚀 Método Recomendado 1: Render.com (Rápido y con SSL Gratis)

Render es una de las plataformas más sencillas para desplegar aplicaciones Node.js:

### Paso 1: Subir el proyecto a GitHub
1. Creá una cuenta en [GitHub.com](https://github.com) si aún no tenés una.
2. Creá un nuevo repositorio (por ejemplo, `club-tercer-tiempo`).
3. Subí el contenido de esta carpeta (`club-gestion-pagos`) al repositorio.

### Paso 2: Crear el servicio en Render
1. Creá una cuenta gratuita en [Render.com](https://render.com).
2. Hacé clic en **"New +"** -> **"Web Service"**.
3. Conectá tu repositorio de GitHub creado en el Paso 1.
4. Completá los campos:
   * **Name:** `club-tercer-tiempo` (o el nombre que prefieras).
   * **Region:** Ohio (US East) o la más cercana.
   * **Runtime:** `Node`.
   * **Build Command:** `npm install`
   * **Start Command:** `npm start`
5. Hacé clic en **"Create Web Service"**.

Render compilará el proyecto y en unos minutos te entregará una URL pública con candado de seguridad HTTPS (ejemplo: `https://club-tercer-tiempo.onrender.com`).

---

## 🚆 Método Recomendado 2: Railway.app (Ideal para SQLite)

Railway es excelente para proyectos que utilizan SQLite porque permite añadir un disco persistente (Volume) con 1 clic:

1. Entrá a [Railway.app](https://railway.app) y registrate con tu cuenta de GitHub.
2. Creá un **"New Project"** -> **"Deploy from GitHub repo"**.
3. Seleccioná el repositorio del club.
4. En la pestaña **Settings**, hacé clic en **"Generate Domain"** para obtener tu enlace web público HTTPS.
5. (Opcional): En la pestaña **Volumes**, podés crear un volumen persistente montado en `/app` para garantizar que el archivo `club.db` nunca se reinicie.

---

## 🌐 Configuración de Dominio Propio (ej: `clubtercertiempo.ar`)

Si el club registra su propio dominio en **NIC Argentina** (por ejemplo, `clubtercertiempo.ar` o `.com`):

1. En Render o Railway, andá a la sección **Custom Domains**.
2. Escribí el dominio del club (ej. `panel.clubtercertiempo.ar`).
3. Te dará un registro **CNAME** o **A** para pegar en el panel de tu registrador de dominio.
4. ¡Listo! El certificado de seguridad SSL se genera solo de forma automática.

---

## 🔒 Buenas Prácticas para Producción
* **Respaldos periódicos:** Periódicamente podés descargar una copia del archivo `club.db` desde el servidor para tener un backup físico de seguridad de todas las cuotas y cobros.
* **Acceso de los Socios:** Los socios ingresan directamente a `https://tu-dominio/socio.html` o escanean el QR de su carnet.
