# ⚽ ClubGestión - Control de Socios, Pagos y Cuotas

Sistema MVP integral desarrollado en **Node.js, Express, SQLite y Tailwind CSS** para la administración de cuotas sociales, aranceles de disciplinas, cobranzas y carnet digital con control de acceso por código QR.

---

## 🚀 Cómo Iniciar el Sistema

1. **Ubicación del proyecto:**
   ```bash
   cd "C:\Users\Usuario\.gemini\antigravity\scratch\club-gestion-pagos"
   ```

2. **Iniciar servidor:**
   ```bash
   node server.js
   ```

3. **Abrir en el navegador:**
   [http://localhost:3000](http://localhost:3000)

---

## 🗄️ Modelo de Datos (Base de Datos Relacional)

```
+--------------------+       +-------------------------+       +--------------------+
|     CATEGORIAS     |       |         SOCIOS          |       |    DISCIPLINAS     |
+--------------------+       +-------------------------+       +--------------------+
| id (PK)            |<------| categoria_id (FK)       |       | id (PK)            |
| nombre             |       | id (PK)                 |       | nombre             |
| cuota_base         |       | numero_socio (UNIQUE)   |       | arancel_mensual    |
| descripcion        |       | dni (UNIQUE)            |       | profesor           |
+--------------------+       | nombre, apellido        |       | dias_horarios      |
                             | email, telefono         |       +---------^----------+
                             | estado (Activo/Inactivo)|                 |
                             | grupo_familiar_id       |                 |
                             +------------+------------+                 |
                                          |                              |
                                          | 1:N                          | M:N
                                          v                              |
                             +-------------------------+                 |
                             |   SOCIO_DISCIPLINAS     |-----------------+
                             +-------------------------+
                             | id (PK)                 |
                             | socio_id (FK)           |
                             | disciplina_id (FK)      |
                             +-------------------------+
                                          |
                                          | 1:N
                                          v
+--------------------+       +-------------------------+
|       PAGOS        |       |         CUOTAS          |
+--------------------+       +-------------------------+
| id (PK)            |       | id (PK)                 |
| cuota_id (FK)      |<------| socio_id (FK)           |
| socio_id (FK)      |       | periodo (YYYY-MM)       |
| monto_pagado       |       | concepto                |
| medio_pago         |       | monto_original          |
| nro_comprobante    |       | descuento / recargo     |
| fecha_pago         |       | monto_total             |
| observaciones      |       | fecha_vencimiento       |
| cajero             |       | estado (Pendiente/Pago) |
+--------------------+       +-------------------------+
```

---

## 🌟 Funcionalidades Implementadas

1. **Dashboard en Tiempo Real:**
   - Total de socios activos y facturación mensual.
   - Total cobrado vs. saldo pendiente / mora.
   - Tasa de cobro porcentual.
   - Lista prioritaria de socios morosos y últimos cobros registrados.

2. **Gestión de Socios:**
   - Alta con asignación de categoría y múltiples actividades/disciplinas simultáneas.
   - Búsqueda en tiempo real por DNI, Nombre o N° de Socio.
   - Visualización instantánea del estado de cuotas de cada socio.

3. **Motor de Emisión Masiva de Cuotas:**
   - Cálculo automático por socio: `Cuota Base (Categoría) + Σ Aranceles (Disciplinas activas)`.
   - Evita duplicación de períodos ya facturados.

4. **Caja y Cobros:**
   - Registro con selección de medio: Efectivo, Transferencia, Mercado Pago, Débito, Crédito.
   - Generación de comprobante correlativo (`REC-2026-XXXXX`).
   - Modal de recibo con opción de impresión directa (`Ctrl + P`).

5. **Carnet Digital & Validación QR:**
   - Credencial digital individual para cada socio.
   - Generación dinámica de código QR con el estado de habilitación:
     - 🟢 **Habilitado:** Si está activo y sin deudas.
     - 🔴 **Inhabilitado:** Si registra cuotas impagas (indica cantidad y monto adeudado).

6. **Portal de Autogestión del Socio (`/socio.html`):**
   - Acceso ágil con DNI o N° de Socio (diseño móvil para celulares).
   - Consulta de cuotas al día o adeudadas.
   - Datos bancarios oficiales del club (CBU, Alias con botón de copiado).
   - Formulario para **informar pago por transferencia** adjuntando foto/captura del comprobante y N° de transacción.

7. **Bandeja de Conciliación de Tesorería:**
   - Visualización de comprobantes pendientes con foto ampliable.
   - Botón **"Aprobar"**: Acredita el dinero en caja, salda la cuota y habilita el carnet del socio.
   - Botón **"Rechazar"**: Permite indicar un motivo de rechazo que el socio ve en su portal.
